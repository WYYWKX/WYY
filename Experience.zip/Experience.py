import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.inspection import permutation_importance
from sklearn.base import BaseEstimator, RegressorMixin

excel_data_path = r'F:\Python Codes\Experience\oasis_cross-sectional-5708aa0a98d82080.xlsx'
excel_reliability_path = r'F:\Python Codes\Experience\oasis_cross-sectional-reliability-063c8642b909ee76.xlsx'

data = pd.read_excel(excel_data_path)
reliability_data = pd.read_excel(excel_reliability_path)

# 合并两个Excel文件的数据
combined_data = pd.merge(data, reliability_data, on='ID', how='left', suffixes=('_x', '_y'))

combined_data['group'] = combined_data['CDR'].apply(lambda x: 'HC' if x == 0 else ('MCI' if x == 0.5 else 'AD'))

# 使用'nWBV_x'作为海马体体积的代理变量
selected_columns = ['ID', 'group', 'Age', 'Educ', 'MMSE', 'eTIV_x', 'nWBV_x']
selected_data = combined_data[selected_columns].copy()  # 显式复制以避免Pandas警告

numeric_columns = selected_data.select_dtypes(include=[np.number]).columns
non_numeric_columns = selected_data.select_dtypes(exclude=[np.number]).columns

selected_data.loc[:, numeric_columns] = selected_data[numeric_columns].fillna(selected_data[numeric_columns].median())

for col in non_numeric_columns:
    mode_value = selected_data[col].mode().iloc[0] if not selected_data[col].mode().empty else None
    selected_data.loc[:, col] = selected_data[col].fillna(mode_value)

le = LabelEncoder()
selected_data['group_encoded'] = le.fit_transform(selected_data['group'])

X = selected_data.drop(['ID', 'group', 'MMSE'], axis=1)  # MMSE作为预测目标
y = selected_data['MMSE']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).view(-1, 1)

train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# 构建神经网络模型
class Net(nn.Module):
    def __init__(self, input_dim):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_dim, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.dropout = nn.Dropout(0.2)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x

model = Net(input_dim=X_train.shape[1])

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
num_epochs = 100

for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for inputs, targets in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss / len(train_loader):.4f}')

# 评估模型
model.eval()
with torch.no_grad():
    predictions = model(X_test_tensor).flatten().numpy()
    y_test_np = y_test_tensor.flatten().numpy()
    test_loss = criterion(torch.tensor(predictions, dtype=torch.float32).view(-1, 1), y_test_tensor).item()
print(f'Test Loss: {test_loss}')

class TorchModelAdapter(BaseEstimator, RegressorMixin):
    def __init__(self, model, device='cpu'):
        self.model = model
        self.device = device

    def fit(self, X, y):
        pass

    def predict(self, X):
        self.model.eval()
        with torch.no_grad():
            X_tensor = torch.tensor(X, dtype=torch.float32)
            predictions = self.model(X_tensor).flatten().numpy()
        return predictions

adapter = TorchModelAdapter(model)

perm_importance = permutation_importance(
    adapter, 
    X_test, 
    y_test.values, 
    scoring='neg_mean_squared_error', 
    n_repeats=5, 
    random_state=42
)
feature_names = selected_data.drop(['ID', 'group', 'MMSE'], axis=1).columns
sorted_idx = perm_importance.importances_mean.argsort()

# 特征重要性分析图
plt.figure(figsize=(10, 6))
plt.barh(feature_names[sorted_idx], perm_importance.importances_mean[sorted_idx])
plt.xlabel("Permutation Importance")
plt.title('Feature Importance Analysis')
plt.tight_layout()
plt.savefig('feature_importance.png')  
plt.show()

# 真实值与预测值对比图
plt.figure(figsize=(10, 6))
plt.scatter(y_test, predictions)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], '--k')
plt.xlabel('True Values [MMSE]')
plt.ylabel('Predictions [MMSE]')
plt.title('True Values vs Predictions')
plt.tight_layout()
plt.savefig('true_vs_predictions.png')  
plt.show()

# 残差分布图
residuals = y_test - predictions
plt.figure(figsize=(10, 6))
sns.histplot(residuals, kde=True)
plt.title('Residual Distribution')
plt.xlabel('Residuals')
plt.tight_layout()
plt.savefig('residual_distribution.png')  
plt.show()